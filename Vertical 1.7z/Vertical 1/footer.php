<!-- Abrir footer -->
<footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="index.php" class="nav-link px-2 text-muted">Inicio</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Privacidad</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">¿Necesitas ayuda?</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Contactenos</a></li>
    </ul>
    <p class="text-center text-muted">© 2021 Historial clínico <br> Garzón-Huila</p>
  </footer>
<!-- Cerrar footer -->