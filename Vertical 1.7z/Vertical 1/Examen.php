
<!-- Historial clinico pagina grupo 2 21/10/21-->

<!doctype html>

<html lang="es">

  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="main.css" rel="stylesheet">
    

    
    <title>Historial clinico</title>
  </head>

  <body>
  <?php
include "menu.php";
?>
      
    </ul>

    <div class="d-flex justify-content-center">
      <img src="img/logo.png" class="img-fluid" width=80px;  alt="logo">
      <h1 class="my-4"> HISTORIAL CLINICO</h1>
    </div>
<br>
<br>

  <div class="mx-5">
    <h4>DATOS PERSONALES</h4>
      <form class="row g-3 needs-validation" validate>
        
    

        <div class=" col-md-5">
          <label for="validationCustom01" class="form-label ">Fecha del Historial</label>
            <input type="date" class="form-control" id="validationCustom01"  required>
          <div class="invalid-feedback">
            
            Proporcione infromación válida.
          </div>
        </div>


        <div class="col-md-2"></div>


        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Anexo de Historial fisico </label>
          <input class="form-control" type="file" id="validationCustom01" id="formFile">
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

    
        <div class="col-md-4">
          <label for="validationCustom02" class="form-label">Paciente</label>
          <input type="text" class="form-control" id="validationCustom02" placeholder="Nombre del paciente" required>
          <div class="invalid-feedback">
          <script>swal("Oops!", "Something went wrong on the page!", "error");</script>
          Proporcione infromación válida.
          </div>
        </div>


        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">N° de cedula</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="N° Cedula" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>


        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Sexo</label>
          <select class="form-select" id="validationCustom01" required>
            <option selected>Elegir</option>
            <option value="1">Femenino</option>
            <option value="2">Masculino</option>
          </select>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Entidad</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="Entidad" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">F. de Nacimiento</label>
          <input type="date" class="form-control" id="validationCustom01"  required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4">

        </div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Edad</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="Edad" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Estado Civil</label>
          <select class="form-select" id="validationCustom01">
            <option selected>Elegir</option>
            <option value="1">Soltero-a</option>
            <option value="2">Casado-a</option>
            <option value="2">Unión Libre</option>
            <option value="2">Divorciado</option>
          </select>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4"></div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Teléfono</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="Teléfono" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>
        

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Ocupación</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="Ocupación" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4"></div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">E-mail</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="E-mail" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4">
          <label for="validationCustom01" class="form-label">Dirección</label>
          <input type="text" class="form-control" id="validationCustom01" placeholder="Dirección" required>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-4"></div>

        <p></p>

        <h4>ANTECEDENTES PERSONALES</h4>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Hospitalarios</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Motivo de Consulta </label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea2" style="height: 100px"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Quirúrgicos</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Historia de la Enfermedad Actual</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea2" style="height: 100px"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Traumáticos</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>

        <div class="col-md-5">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Alérgicos</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>
        <div class="col-md-5">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Otros</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <p></p>

        <h4>EXAMEN FÍSICO</h4>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Signos vitales</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label"><strong>CONDUCTAS A SEGUIR</strong> </label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea2" style="height: 100px"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Estado General</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>
        <div class="col-md-5">
          
        </div>
      <p></p>

        <h4>IMPRESION DIAGNOSTICA</h4>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Dx Principal</label>
          <textarea class="form-control" placeholder="Digite información"  id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>
        <div class="col-md-5">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Dx Relacional</label>
          <textarea class="form-control" placeholder="Digite información" id="validationCustom01" id="floatingTextarea"></textarea>
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>

        <div class="col-md-2">
          
        </div>

        <div class="col-md-5">
          <label for="validationCustom01" class="form-label">Firma </label>
          <input class="form-control" type="file" id="validationCustom01" id="formFile">
          <div class="invalid-feedback">
          Proporcione infromación válida.
          </div>
        </div>
        <br>
          <br>
          <br>
          <br> <br>
          <br>
          <br>
    
       
        <div class="col-12 d-flex justify-content-center">
         
          <br>
          <br>
          <button class="btn btn-primary" type="submit">Guardar Información</button>
        </div>

        <a  href="javascript:window.print()">
Descargar Archivo
</a>

















    <script>// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()</script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>