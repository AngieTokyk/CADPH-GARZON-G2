-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-10-2021 a las 17:23:49
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `historial`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_clinico`
--

CREATE TABLE `historial_clinico` (
  `HisPaciente` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `HisCedula` int(10) NOT NULL,
  `HisFeNacimiento` date NOT NULL,
  `HisFeHistorial` date NOT NULL,
  `HisConsulta` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `HisTelefono` int(10) NOT NULL,
  `HisMedico` varchar(50) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `historial_clinico`
--

INSERT INTO `historial_clinico` (`HisPaciente`, `HisCedula`, `HisFeNacimiento`, `HisFeHistorial`, `HisConsulta`, `HisTelefono`, `HisMedico`) VALUES
('Angie Lizeth Toquica Perdomo', 55063045, '1990-10-19', '2022-12-22', 'Cefalea', 322564782, 'Martha Lucía Pérez'),
('Brayan Prada Monsalve', 55231414, '1981-05-12', '2021-04-14', 'Condromalacia rotuliana', 321456987, 'Andrés Camilo Torres'),
('Martha Cecilia Rodríguez Núñez', 103245684, '1971-01-19', '2021-03-25', 'Dolor estomacal', 324561452, 'Rolando Rodríguez'),
('Juan Esteban Barrera', 1094512567, '1981-08-18', '0200-02-20', 'Infección urinaria', 321456789, 'Olga Guzmán '),
('Jesús Andrés Silva Plazas', 2003456214, '0000-00-00', '2020-06-27', 'trauma craneoencefálico', 312458623, 'Martha Lucía Pérez');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `PaCedula` int(10) NOT NULL,
  `PaNombre` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `PaFechaHistorial` date NOT NULL,
  `PaEdad` int(2) NOT NULL,
  `PaEstadoCivil` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `PaTelefono` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`PaCedula`, `PaNombre`, `PaFechaHistorial`, `PaEdad`, `PaEstadoCivil`, `PaTelefono`) VALUES
(55063045, 'Angie Lizeth Toquica Perdomo', '2020-12-22', 31, 'soltera', 322564782),
(55231414, 'Brayan Prada Monsalve', '2021-04-14', 40, 'soltero', 321456987),
(103245684, 'Martha Cecilia Rodríguez Núñez', '2021-03-25', 50, 'casada', 324561452),
(1094512567, 'Juan Esteban Barrera', '2020-02-20', 40, 'unión libre', 321456789),
(2003456214, 'Jesús Andrés Silva Plazas', '2020-06-27', 45, 'casado', 312458623);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_salud`
--

CREATE TABLE `personal_salud` (
  `PeNombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `PeDocumento` int(10) NOT NULL,
  `PeContraseña` varchar(10) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `personal_salud`
--

INSERT INTO `personal_salud` (`PeNombre`, `PeDocumento`, `PeContraseña`) VALUES
('Andrés Camilo Torres', 1003456321, 'historialg'),
('Martha Lucía Pérez', 1042589631, 'historialg'),
('Olga Gúzman', 55025634, 'historialg'),
('Rolando Rodríguez', 1023698742, 'historialg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `historial_clinico`
--
ALTER TABLE `historial_clinico`
  ADD KEY `HisCedula` (`HisCedula`),
  ADD KEY `HisMedico` (`HisMedico`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`PaCedula`);

--
-- Indices de la tabla `personal_salud`
--
ALTER TABLE `personal_salud`
  ADD PRIMARY KEY (`PeNombre`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `historial_clinico`
--
ALTER TABLE `historial_clinico`
  ADD CONSTRAINT `historial_clinico_ibfk_1` FOREIGN KEY (`HisCedula`) REFERENCES `paciente` (`PaCedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historial_clinico_ibfk_2` FOREIGN KEY (`HisMedico`) REFERENCES `personal_salud` (`PeNombre`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
